clc;clearvars;close all
%% add path
addpath('C:\Users\jinho\OneDrive\Desktop\Datascience\2019_03_03_BCT')

%% param
year=[2024];

%% example 
IN_Strength = cell(size(year));
%% load
for i = 1:length(year)
    filename = ['GCC_Bank',num2str(year(i)),'.mat'];
    load(filename);
    G = digraph(AdjG)
    %  compute instrength
    [ins,outs, stren] = strengths_dir(AdjG);
    %Highest connected node by number of links
    degrees = sum(AdjG, 2);       % sum rows
[~, mostConnected] = max(degrees);
    highNodes=Nodi.Name{mostConnected}; %highest
    %betweenness centrality
    bc=centrality(G,'betweenness');
    [~, maxBCnode] = max(bc);
    Nodi.Name{maxBCnode};
    %Eigenvector
    % Eigenvector centrality/pagerank
    ec = centrality(G, 'pagerank');
    % Nodo con valore massimo di eigenvector centrality
    [~, maxECnode] = max(ec);
    % Nome del nodo più centrale secondo eigenvector
    Nodi.Name{maxECnode}


end