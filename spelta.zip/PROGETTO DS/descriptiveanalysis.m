function [outputArg1,outputArg2] = descriptiveanalysis(inputArg1,inputArg2)
%DESCRIPTIVEANALYSIS Summary of this function goes here
%   Detailed explanation goes here
arguments (Input)
    inputArg1
    inputArg2
end

arguments (Output)
    outputArg1
    outputArg2
end

outputArg1 = inputArg1;
outputArg2 = inputArg2;
end